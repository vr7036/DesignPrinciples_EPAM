abstract public class Calculator {
double x,y;
Calculator(double n1,double n2){
    x=n1;
    y=n2;
}
abstract double calculate();
}
